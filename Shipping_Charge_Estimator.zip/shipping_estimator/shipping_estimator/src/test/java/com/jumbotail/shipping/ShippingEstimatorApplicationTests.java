package com.jumbotail.shipping;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ShippingEstimatorApplicationTests {

	@Test
	void contextLoads() {
	}

}
